#ifndef __USART2_H_
#define __USART2_H_

#include "sys.h"

void USART2_Init(u32 bound);

#endif

