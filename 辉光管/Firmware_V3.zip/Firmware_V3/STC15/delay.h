
#ifndef	__DELAY_H
#define	__DELAY_H

#include	"config.h"

void  Delay_ms(uint8_t ms);
void Delay5us();

#endif
