#ifndef __LED_H
#define __LED_H	 
#include "sys.h"


#define OnboardLED PBout(9)		//PB9 ����LED

void LED_Init(void);		//LED��ʼ��

		 				    
#endif
