#ifndef __USART1_H
#define __USART1_H
#include "sys.h"


void uart1_init(u32 pclk2,u32 bound);

#endif	   
