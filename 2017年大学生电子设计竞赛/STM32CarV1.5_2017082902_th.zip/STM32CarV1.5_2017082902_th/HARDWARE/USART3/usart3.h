#ifndef __USART3_H
#define __USART3_H	 

#include "sys.h"

void uart3_init(u32 pclk2,u32 bound);

		 				    
#endif
