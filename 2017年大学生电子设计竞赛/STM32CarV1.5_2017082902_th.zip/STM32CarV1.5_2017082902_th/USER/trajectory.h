#ifndef __TRAJECTORY_H
#define __TRAJECTORY_H

#include "sys.h"

void CarRun(u8 garage);


		 				    
#endif
